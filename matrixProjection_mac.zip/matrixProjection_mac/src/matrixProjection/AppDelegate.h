//
// AppDelegate.h
// =============
// matrixProjection
//
//  AUTHOR: Song Ho Ahn (song.ahn@gmail.com)
// CREATED: 2012-06-15
// UPDATED: 2012-06-18
//
// Copyright (c) 2012 Song Ho Ahn. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "ViewGL.h"
#import "ModelGL.h"

@interface AppDelegate : NSObject <NSApplicationDelegate>
{
    ModelGL model; // model component
}

@property (assign) IBOutlet NSWindow *window;

// view component
@property (unsafe_unretained) IBOutlet ViewGL *viewGL;

// radio control for projection types
@property (unsafe_unretained) IBOutlet NSMatrix *radioProjection;

// radio control for rendering modes
@property (unsafe_unretained) IBOutlet NSMatrix *radioRenderMode;

// controls for frustum params
@property (unsafe_unretained) IBOutlet NSTextField *textLeft;
@property (unsafe_unretained) IBOutlet NSTextField *textRight;
@property (unsafe_unretained) IBOutlet NSTextField *textBottom;
@property (unsafe_unretained) IBOutlet NSTextField *textTop;
@property (unsafe_unretained) IBOutlet NSTextField *textNear;
@property (unsafe_unretained) IBOutlet NSTextField *textFar;
@property (unsafe_unretained) IBOutlet NSStepper *stepLeft;
@property (unsafe_unretained) IBOutlet NSStepper *stepRight;
@property (unsafe_unretained) IBOutlet NSStepper *stepBottom;
@property (unsafe_unretained) IBOutlet NSStepper *stepTop;
@property (unsafe_unretained) IBOutlet NSStepper *stepNear;
@property (unsafe_unretained) IBOutlet NSStepper *stepFar;

// control for matrix elements
@property (unsafe_unretained) IBOutlet NSMatrix *matProjection;

// control for OpenGL function calls
@property (unsafe_unretained) IBOutlet NSTextField *textProjectionMatrix;

// user event handlers
- (IBAction) stepperClicked: (id)sender;
- (IBAction) radioClicked: (id)sender;
- (IBAction) resetProjectionMatrix: (id)sender;

- (void) updateMatrixElements;
- (void) updateProjectionMatrixCalls;

@end
