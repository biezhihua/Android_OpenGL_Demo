//
// AppDelegate.mm
// ==============
// matrixProjection
//
//  AUTHOR: Song Ho Ahn (song.ahn@gmail.com)
// CREATED: 2012-06-15
// UPDATED: 2012-06-18
//
// Copyright (c) 2012 Song Ho Ahn. All rights reserved.
//

#import "AppDelegate.h"
#import <sstream>

@implementation AppDelegate

@synthesize window;
@synthesize viewGL;
@synthesize radioProjection;
@synthesize radioRenderMode;
@synthesize textLeft;
@synthesize textRight;
@synthesize textBottom;
@synthesize textTop;
@synthesize textNear;
@synthesize textFar;
@synthesize stepLeft;
@synthesize stepRight;
@synthesize stepBottom;
@synthesize stepTop;
@synthesize stepNear;
@synthesize stepFar;
@synthesize matProjection;
@synthesize textProjectionMatrix;



///////////////////////////////////////////////////////////////////////////////
- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // first, tell view module which is the model component 
    [viewGL setModel:&model];

    // OpenGL RC should be ready at this point, init OpenGL states here
    model.init();

    // get size of opengl window, and pass it to model component
    NSRect rect = [viewGL bounds];
    model.setWindowSize((int)rect.size.width, (int)rect.size.height);    

    // init steppers (IB does not allow float number for increment)
    [stepLeft setIncrement:0.1];
    [stepRight setIncrement:0.1];
    [stepBottom setIncrement:0.1];
    [stepTop setIncrement:0.1];
    [stepNear setIncrement:1];
    [stepFar setIncrement:1];

    // init other controls
    [self resetProjectionMatrix:nil];
}



///////////////////////////////////////////////////////////////////////////////
- (id) init
{
    self = [super init];
    if(self != nil)
    {
        //printf("Initializing AppDelegate.\n");
    }
    return self;
}



///////////////////////////////////////////////////////////////////////////////
- (void) awakeFromNib
{
    //printf("awakeFromNib\n");
}



///////////////////////////////////////////////////////////////////////////////
- (void) applicationWillTerminate: (NSNotification*)notification
{
    //printf("will terminate\n");
}



///////////////////////////////////////////////////////////////////////////////
- (BOOL) applicationShouldTerminateAfterLastWindowClosed: (NSApplication*) application
{
    //printf("applicationShouldTerminateAfterLastWindowClosed\n");
    // terminate app
    return YES;
}



///////////////////////////////////////////////////////////////////////////////
//- (IBAction) controlTextDidChange: (NSNotification*) notification
//{
//    printf("controlTextChanged\n");
//}



///////////////////////////////////////////////////////////////////////////////
- (IBAction) stepperClicked: (id)sender
{
    NSNumberFormatter* formatter = [[NSNumberFormatter alloc] init];
    [formatter setFormat:@"#0.#"];
    float value = [sender floatValue];
    NSString* valueStr = [formatter stringFromNumber:[NSNumber numberWithFloat:value]];

    if(sender == stepLeft)
    {
        [textLeft setStringValue:valueStr];
        model.setProjectionLeft(value);
    }
    else if(sender == stepRight)
    {
        [textRight setStringValue:valueStr];
        model.setProjectionRight(value);
    }
    else if(sender == stepBottom)
    {
        [textBottom setStringValue:valueStr];
        model.setProjectionBottom(value);
    }
    else if(sender == stepTop)
    {
        [textTop setStringValue:valueStr];
        model.setProjectionTop(value);
    }
    else if(sender == stepNear)
    {
        [textNear setStringValue:valueStr];
        model.setProjectionNear(value);
    }
    else if(sender == stepFar)
    {
        [textFar setStringValue:valueStr];
        model.setProjectionFar(value);
    }

    [self updateProjectionMatrixCalls];
    [self updateMatrixElements];

    model.draw();
    [[viewGL openGLContext] flushBuffer]; // swap OpenGL framebuffers
}



///////////////////////////////////////////////////////////////////////////////
- (IBAction) radioClicked: (id)sender
{
    int mode = (int)[[sender selectedCell] tag];

    if(sender == radioProjection)
    {
        model.setProjectionMode(mode);
        [self updateProjectionMatrixCalls];
        [self updateMatrixElements];
    }
    else if(sender == radioRenderMode)
    {
        model.setDrawMode(mode);
        model.draw(); // need to draw once here
    }

    model.draw();
    [[viewGL openGLContext] flushBuffer]; // swap OpenGL framebuffers
}



///////////////////////////////////////////////////////////////////////////////
- (void) resetProjectionMatrix: (id)sender
{
    [textLeft setFloatValue:-0.5f];
    [textRight setFloatValue:0.5f];
    [textBottom setFloatValue:-0.5f];
    [textTop setFloatValue:0.5f];
    [textNear setFloatValue:1.0f];
    [textFar setFloatValue:10.0f];

    [stepLeft setFloatValue:-0.5f];
    [stepRight setFloatValue:0.5f];
    [stepBottom setFloatValue:-0.5f];
    [stepTop setFloatValue:0.5f];
    [stepNear setFloatValue:1.0f];
    [stepFar setFloatValue:10.0f];

    // update opengl view matrix
    model.setProjection(-0.5f, 0.5f, -0.5f, 0.5f, 1.0f, 10.0f);

    [self updateProjectionMatrixCalls];
    [self updateMatrixElements];

    // redraw opengl scene
    model.draw();
    [[viewGL openGLContext] flushBuffer];
}



///////////////////////////////////////////////////////////////////////////////
- (void) updateMatrixElements
{
    NSNumberFormatter* formatter = [[NSNumberFormatter alloc] init];
    [formatter setFormat:@"#0.00"];
    NSString* formattedStr;

    const float* projElements = model.getProjectionMatrixElements();

    for(int i = 0; i < 4; ++i)
    {
        for(int j = 0; j < 4; ++j)
        {
            // model matrix
            formattedStr = [formatter stringFromNumber:[NSNumber numberWithFloat:projElements[i*4+j]]];
            [[matProjection cellAtRow:i column:j] setStringValue:formattedStr];
        }
    }
}



///////////////////////////////////////////////////////////////////////////////
- (void) updateProjectionMatrixCalls
{
    // values are negated and order is reversed because it is for camera transform
    std::stringstream ss;
    ss << "glMatrixMode(GL_PROJECTION);\n"
    << "glLoadIdentity();\n";

    if(model.getProjectionMode() == 0)
        ss << "glFrustum(";
    else
        ss << "glOrtho(";

    ss << model.getProjectionLeft() << ", "
       << model.getProjectionRight() << ", "
       << model.getProjectionBottom() << ", "
       << model.getProjectionTop() << ", "
       << model.getProjectionNear() << ", "
       << model.getProjectionFar() << ");\n"
       << std::ends;

    [textProjectionMatrix setStringValue:[NSString stringWithUTF8String:ss.str().c_str()]];
}

@end
